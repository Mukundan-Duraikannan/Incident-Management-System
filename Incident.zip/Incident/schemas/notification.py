from pydantic import BaseModel
from datetime import datetime
from models.notification import Notification


class NotificationResponse(BaseModel):
    id: int
    user_id: int
    message: str
    is_read: bool
    created_at: datetime

    class Config:
        from_attributes = True
